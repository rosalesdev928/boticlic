package com.boticlic.boticlic.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.securityAuthController.java.Keys;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;

@Component
public class JwtUtil {

    private final SecretKey key = Keys.hmacShaKeyFor(
            "boticlic-clave-super-secreta-2026-ok".getBytes()
    );
    private final long EXPIRACION = 1000 * 60 * 60 * 8; // 8 horas

    public String generarToken(String email, String rol) {
        return Jwts.builder()
                .subject(email)
                .claim("rol", rol)
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + EXPIRACION))
                .signWith(key)
                .compact();
    }

    public String extraerEmail(String token) {
        return parsear(token).getSubject();
    }

    public String extraerRol(String token) {
        return (String) parsear(token).get("rol");
    }

    public boolean esValido(String token) {
        try { parsear(token); return true; }
        catch (Exception e) { return false; }
    }

    private Claims parsear(String token) {
        return Jwts.parser().verifyWith(key).build()
                .parseSignedClaims(token).getPayload();
    }
}